﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DoubleSwords_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "本骰子中使用的书页恢复体力时将同时恢复混乱抗性\r\n战斗开始时自身拥有”结晶硬血”则在这一幕中获得一颗斩击反击骰子(4-8[命中时]施加1层[流血])";
    }
}
