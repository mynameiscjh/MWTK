﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_Scourge_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "本速度骰子中的书页对自身施加”流血”时将同时对两名敌方角色施加一次\r\n自身在一幕中若至少承受了15点”流血”伤害则在这一幕结束时恢复1点光芒";
    }
}
