﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_Sword_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "本速度骰子中投掷进攻型骰子时不再受到流血伤害转而获得等量”结晶硬血”(单次至多3层)\r\n自身”结晶硬血”层数不低于10时本速度骰子中使用书页时消耗3层并使进攻型骰子威力+2\r\n";
    }
}
