﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_Blade_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "本速度骰子使用书页期间若自身”血羽”与”结晶硬血”层数之和不低于30则与目标拼点时目标受到的”流血”伤害将扩散至两名敌方角色";
    }
}
