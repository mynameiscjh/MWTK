﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_Armour_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身”血羽”不低于10层时本速度骰子恢复体力溢出时将转化为等量护盾\r\n自身拥有护盾时使自身所有防御型骰子威力+2\r\n";
    }
}
