﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_Lance_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "若本速度骰子使用书页时速度不低于6则使该书页施加的”流血”层数翻倍且以本书页消耗”血羽”时返还消耗量/2";
    }
}
