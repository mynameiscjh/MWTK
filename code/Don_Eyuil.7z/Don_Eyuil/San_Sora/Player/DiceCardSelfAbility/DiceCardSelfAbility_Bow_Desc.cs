﻿namespace Don_Eyuil.San_Sora.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_Bow_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "本速度骰子中使用的书页将变为远程书页(无法对E.G.O书页与群体生效)且进攻型骰子最小值+2\r\n自身每幕第一张使用的书页施加的”流血”层数额外+1";
    }
}
