﻿using Don_Eyuil.Don_Eyuil.Buff;

namespace Don_Eyuil.Don_Eyuil.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_61 : DiceCardSelfAbilityBase
    {
        public static string Desc = "本书页命中目标时将使自身获得3点护盾";

        public override void OnSucceedAreaAttack(BattleUnitModel target)
        {
            BattleUnitBuf_PhysicalShield.AddBuf(owner, 3);
        }
    }
}
