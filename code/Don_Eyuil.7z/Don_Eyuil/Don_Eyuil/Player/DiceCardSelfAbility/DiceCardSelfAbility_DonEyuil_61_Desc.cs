﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_61_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身护盾减少时将视作受到等量\"流血\"伤害\r\n每幕结束时自身每有一颗未被使用的防御型骰子便使自身获得10点护盾\r\n自身拥有护盾时被命中时对命中者施加1-2层\"流血\"\r\n自身陷入混乱时若护盾层数不低于30层则消耗30层护盾并解除混乱";
    }
}
