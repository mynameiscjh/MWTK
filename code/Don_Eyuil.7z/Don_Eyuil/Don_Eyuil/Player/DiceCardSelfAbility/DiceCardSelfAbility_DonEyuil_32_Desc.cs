﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_32_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身命中带有流血的目标时造成的混乱伤害增加25%同时使自身获得1层\"结晶硬血\"\r\n下令战斗时若自身至少拥有6层\"结晶硬血\"则使自身获得一颗反击(突刺4-8)骰子\r\n";
    }
}
