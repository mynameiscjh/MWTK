﻿namespace Don_Eyuil.Don_Eyuil.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DmgCount : DiceCardSelfAbilityBase
    {
        public static string Desc = "";
        public int count = 0;
        public override void OnSucceedAttack()
        {
            count++;
        }
    }
}
