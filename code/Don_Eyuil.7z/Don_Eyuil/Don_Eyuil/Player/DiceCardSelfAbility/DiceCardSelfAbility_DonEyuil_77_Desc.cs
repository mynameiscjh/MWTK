﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_77_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身受到单方面攻击时将以一颗(闪避4-8[拼点胜利]对目标施加1层[流血])迎击\r\n自身承受\"流血\"伤害时每承受3点便使下一颗进攻型骰子伤害+1\r\n";
    }
}
