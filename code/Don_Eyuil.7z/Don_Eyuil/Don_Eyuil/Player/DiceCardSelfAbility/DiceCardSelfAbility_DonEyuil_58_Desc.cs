﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_58_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "拼点时自身速度每高于目标2点便使自身所有骰子最大值+1(至多+4)\r\n自身以高于目标至少4点的速度击中目标时将对目标施加1层\"无法凝结的血\"(每幕至多触发3次)若击杀目标则在下一幕获得一层\"热血尖枪\"\r\n";
    }
}
