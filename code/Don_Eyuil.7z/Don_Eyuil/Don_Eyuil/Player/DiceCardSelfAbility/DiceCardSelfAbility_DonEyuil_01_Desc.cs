﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_01_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身命中处于混乱状态的目标时将触发目标\"流血\"(每张书页至多1次)\r\n一幕中敌方每受到20点\"流血\"伤害便使自身抽取一张书页(每幕至多触发1次)\r\n";
    }
}
