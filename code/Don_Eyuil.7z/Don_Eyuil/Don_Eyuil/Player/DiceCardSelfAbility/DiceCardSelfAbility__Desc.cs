﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility__Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身以打击骰子施加\"流血\"时将额外对一名敌方角色施加等量流血\r\n自身每幕最后一张书页施加\"流血\"时将额外对目标施加等量\"血晶荆棘\"\r\n";
    }
}
