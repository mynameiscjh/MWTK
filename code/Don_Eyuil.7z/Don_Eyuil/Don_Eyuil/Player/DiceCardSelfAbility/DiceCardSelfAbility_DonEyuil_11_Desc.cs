﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_11_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "目标每有2层流血便使自身斩击骰子造成的伤害增加10%(至多50%)\r\n所有我方角色每施加50层\"流血\"便使自身获得1层\"汹涌的血潮\"\r\n";
    }
}
