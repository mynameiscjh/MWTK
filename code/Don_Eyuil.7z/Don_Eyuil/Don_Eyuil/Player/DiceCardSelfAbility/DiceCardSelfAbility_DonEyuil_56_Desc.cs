﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DonEyuil_56_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身施加\"流血\"时将对目标与自身额外施加1层\r\n每幕结束时自身每承受2点\"流血\"伤害便时自身获得1层\"硬血结晶\"\r\n若自身至少拥有15层\"硬血结晶\"则使自身斩击骰子最小值+2\r\n";
    }
}
