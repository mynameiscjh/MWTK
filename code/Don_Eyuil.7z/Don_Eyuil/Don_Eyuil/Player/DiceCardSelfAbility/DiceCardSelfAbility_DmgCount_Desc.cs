﻿namespace Don_Eyuil.Don_Eyuil.Player.DiceCardSelfAbility
{
    public class DiceCardSelfAbility_DmgCount_Desc : DiceCardSelfAbilityBase
    {
        public static string Desc = "自身每幕第一颗骰子最小值+3且命中目标时将在本幕对目标施加3层\"流血\"\r\n自身将对每幕第一个击中的目标施加\"深度创痕\"\r\n";
    }
}
